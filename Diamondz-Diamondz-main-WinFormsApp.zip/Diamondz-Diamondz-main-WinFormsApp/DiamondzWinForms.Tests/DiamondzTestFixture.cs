﻿using DiamondzWinForms.Helpers;
using DiamondzWinForms.Models;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace DiamondzWinForms.Tests
{
    [TestFixture]
    public class DiamondszTestFixture
    {
        [Test,
         TestCase(0, false),
         TestCase(1, true),
         TestCase(10, true)]
        public void TestProductIsAvailable(int quantity, bool expected)
        {
            // Arrange
            var product = new Product { InventoryQuantity = quantity };

            // Act
            var result = product.EffectiveIsAvailable;

            // Assert
            Assert.AreEqual(expected, result);
        }

        [Test,
         TestCase("Bérelhető karkötő", true),
         TestCase("Gyémánt nyaklánc", false),
         TestCase(null, false)]
        public void TestProductIsRentable(string? name, bool expected)
        {
            // Arrange
            var product = new Product { ProductName = name };

            // Act
            var result = product.IsRentableProduct;

            // Assert
            Assert.AreEqual(expected, result);
        }

        [Test,
         TestCase("2024-06-01", "2024-06-05", 5),
         TestCase("2024-06-01", "2024-06-01", 1),
         TestCase(null, null, 0)]
        public void TestOrderRentalDays(string? start, string? end, int expected)
        {
            // Arrange
            var order = new Order { RentalStartRaw = start, RentalEndRaw = end };

            // Act
            var result = order.RentalDays;

            // Assert
            Assert.AreEqual(expected, result);
        }
    }
}
